import { NativeCoin } from "@/sdk_bi/entities/ether";

import { Token } from "./token";

export type Currency = NativeCoin | Token;
