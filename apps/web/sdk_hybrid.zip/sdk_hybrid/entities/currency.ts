import { NativeCoin } from "@/sdk_hybrid/entities/ether";

import { Token } from "./token";

export type Currency = NativeCoin | Token;
